# api

Symfony encore flou pour moi, grosse difficulté à mettre en place des principes que je comprends lentement et probleme d'exportation avec github.
devoir fait avec le soutient de plusieur collègues.
- première exportation mise dans mon github afin d'eviter "le devoir non rendu"
- voici la version plus travailler
